PFM test CSV files
Test team. November 18, 2026.

How to use these files
- Each file name is the year of its data, because the program requires YYYY.csv. Every case has its own year, so you can load many files into one account.
- To test the overwrite warning, load valid/2024.csv and then valid/alt/2024.csv.
- We ran the Validation team's CsvValidator on every file. The problem counts below are what it reports.
- The Data Audit results below come from the project spec and from reading the audit code. We have not run them on a build yet.

valid, must load with no problems
- 2024.csv. A typical year that uses every category, including Other as income and as an expense, and a leap day, 02/29/2024.
- 2025.csv. A year with a deficit.
- 2023.csv. One data row.
- 2022.csv. Rows out of date order. The order must not matter.
- 2021.csv. Windows line endings.
- 2030.csv. Boundary values. January 1, December 31, amounts of 1 and negative 1, and the largest Java int, 2147483647.
- alt/2024.csv. A second 2024 file for the overwrite test.

stress
- 2000.csv. 5000 rows. 2000 is a leap year. Loading and analysis should finish in seconds.

invalid, the program must report each problem
- 1998.csv. No header line. The validator reports 1 problem.
- 1999.csv. Lowercase header. The validator reports 1 problem.
- 2001.csv. Header is Date,Type,Amount. The validator reports 1 problem.
- 2002.csv. Seven badly formatted dates. The validator reports 7 problems.
- 2003.csv. Eight impossible dates, such as 02/29/2003 and 04/31/2003. The validator reports 8 problems.
- 2004.csv. Six unknown categories, including an empty one and lowercase food. The validator reports 6 problems.
- 2005.csv. Six bad amounts, such as cents, letters, a blank and a dollar sign. The validator reports 6 problems.
- 2006.csv. Four wrong signs and two zero amounts. The validator reports 6 problems.
- 2007.csv. Wrong column counts, a blank line and a line of only commas. The validator reports 7 problems.
- 2008.csv. Dates from 2008 and 2009 in one file. The validator reports 1 problem.
- 2009.csv. A header and no data rows. The validator reports 1 problem.
- 2010.csv. An empty file. The validator reports 1 problem.
- 2011.csv. The file name says 2011 and the dates say 2012. The validator reports 1 problem.
- my_budget.csv. Valid data with a wrong file name. The validator reports 1 problem.

mixed, valid rows with a few bad rows
- 2014.csv. Ten good rows and two bad rows, line 8 with the date 02/30/2014 and line 12 with the category Groceries. The program must let the user cancel or ignore the bad rows. If the user ignores them, 10 rows load.

anomalous, the format is valid
- 2015.csv. Compensation is 10000 every month except July, when it is 100000. Only the July Compensation entry should be flagged.
- 2020.csv. The same Compensation pattern with small expenses. Only the July entry should be flagged. The audit code compares every amount with the median of all categories together, so it may flag about 24 normal Compensation and Home entries. Check this on the Alpha build.
- 2016.csv. Two Education entries of 8000 among amounts under 1000. Both should be flagged. After the user excludes Education, nothing should be flagged.
- 2017.csv. Steady amounts. Nothing should be flagged.
- 2018.csv. Duplicates. The Food entry on 03/15 appears twice and the Entertainment entry on 07/04 appears three times. The program should report both.

absurd, the program must not crash, hang or show a stack trace
- 2019.csv. The validator reports 6 problems and accepts four amounts that are larger than a Java int, on lines 3, 4, 5 and 11. Check what the loader does with those. The file also has a 500 character category, a quoted category with a comma, an accented category, Chinese characters, Arabic digits and a pasted paragraph.
